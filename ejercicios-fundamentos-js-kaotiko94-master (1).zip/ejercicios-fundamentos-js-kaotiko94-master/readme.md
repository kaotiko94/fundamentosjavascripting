# Ejercicios fundamentos JS

Para ejecutar cada ejercicio y comprobar si pasa los tests hay que ejecutarlo en node:

`node ruta/al/archivo.js`