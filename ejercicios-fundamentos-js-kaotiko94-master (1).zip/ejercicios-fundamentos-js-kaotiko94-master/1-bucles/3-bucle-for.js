// ej 3
// muestra por consola la tabla del 7;
// Utilizad el bucle for

var i;

for (var i =0; i<=10; i++){
   console.log(7 + "*" + i + "=" + (7 * i));
}