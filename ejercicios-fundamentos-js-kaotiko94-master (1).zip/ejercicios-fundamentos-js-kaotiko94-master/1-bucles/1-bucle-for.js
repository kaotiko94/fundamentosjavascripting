// ej 1
// haz un bucle que muestre por consola los números del 4 al 9 inclusive
// Utilizad el bucle for

var i;
for (i=4;i< 10; i++){
    console.log(i);
}