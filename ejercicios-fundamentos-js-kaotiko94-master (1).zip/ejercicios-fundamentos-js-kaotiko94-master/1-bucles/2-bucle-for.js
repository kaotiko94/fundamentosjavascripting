// ej 2
// haz un bucle que muestre por consola los impares del 3 al 17 inclusive
// Utilizad el bucle for


var i

for (var i = 3; i < 18; i++) {
    if (i%2 !=0) 
    console.log(i);
}
