
// ej 9
// Rellena la matriz como la siguiente utilizando bucles for anidados
// let matriz = [
//   ['00','01','02'],
//   ['10','11','12'],
//   ['20','21','22']
// ];

let matriz = [
    ['00','01','02'],
    ['10','11','12'],
    ['20','21','22']
];

for (var i = 0; i < 3; i++) {
    for (var b = 0; b < 3; b++) {
        console.log(i + '' + b);
    }
}
console.log(matriz);
